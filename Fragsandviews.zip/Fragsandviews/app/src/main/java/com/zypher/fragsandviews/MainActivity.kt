package com.zypher.fragsandviews

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.fragment.app.commit
import androidx.fragment.app.FragmentContainerView
import androidx.fragment.app.Fragment
import com.zypher.fragsandviews.ui.theme.FragsandviewsTheme

class MainActivity : ComponentActivity(), InputFragment.InputListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FragsandviewsTheme {
                AppContent()
            }
        }

        // Korrekt hantera initialt tillägg av InputFragment
        if (savedInstanceState == null) {
            supportFragmentManager.commit {
                setReorderingAllowed(true)
                replace(R.id.fragment_container, InputFragment.newInstance())
            }
        }
    }

    @Composable
    fun AppContent() {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            FragmentContainer()
        }
    }

    @Composable
    fun FragmentContainer() {
        // Använder AndroidView för att placera FragmentContainerView i Compose UI
        val context = LocalContext.current
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                FragmentContainerView(ctx).apply {
                    id = R.id.fragment_container // Se till att detta ID finns definierat i din layout resurs
                    // Detta antar att du har hanterat fragment-läggningar i onCreate ovan eller i annan logik
                }
            }
        )
    }

    override fun onInputSent(input: String) {
        // Hanterar input mottaget från InputFragment och startar DrawingFragment
        val drawingFragment = DrawingFragment().apply {
            arguments = Bundle().apply {
                putString("input_key", input)
            }
        }
        supportFragmentManager.commit {
            setReorderingAllowed(true)
            replace(R.id.fragment_container, drawingFragment)
            addToBackStack(null) // Om du vill att användaren ska kunna navigera tillbaka
        }
    }
}
