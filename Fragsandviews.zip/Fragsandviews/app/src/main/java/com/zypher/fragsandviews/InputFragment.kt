package com.zypher.fragsandviews

import android.app.Fragment
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText

class InputFragment : Fragment() {

    private var listener: OnInputListener? = null

    interface OnInputListener {
        fun onInputSent(input: String)
    }
    interface InputListener {
        fun onInputSent(input: String)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnInputListener) {
            listener = context
        } else {
            throw RuntimeException("$context must implement OnInputListener")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_input, container, false)
        val inputEditText = view.findViewById<EditText>(R.id.inputEditText)
        view.findViewById<Button>(R.id.submitBtn).setOnClickListener {
            listener?.onInputSent(inputEditText.text.toString())
        }
        return view
    }
    companion object {
        fun newInstance(): InputFragment {
            return InputFragment()
        }
    }

}


